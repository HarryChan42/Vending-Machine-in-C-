#include "VendingMachine.h"
#include <iostream>
#include <iomanip>

// Item constructor
Item::Item(std::string n, double p, int q)
    : name(n), price(p), quantity(q) {}

// Slot constructor
Slot::Slot(std::string c, Item it)
    : code(c), item(it) {}

// VendingMachine constructor
VendingMachine::VendingMachine()
    : insertedMoney(0.0), totalEarnings(0.0), OWNER_PASSWORD("admin123")
{
    initializeInventory();
}

void VendingMachine::initializeInventory() {
    slots = {
        {"A1", Item("Coca Cola", 1.50, 10)},
        {"A2", Item("Pepsi",     1.50, 10)},
        {"A3", Item("Water",     1.00, 10)},
        {"B1", Item("Snickers",  1.25, 10)},
        {"B2", Item("Chips",     1.75, 10)},
        {"B3", Item("Oreo",      2.00, 10)},
        {"C1", Item("Gum",       0.75, 10)},
        {"C2", Item("Red Bull",  2.50, 10)}
    };
}

void VendingMachine::insertMoney(double amount) {
    if (amount > 0) {
        insertedMoney += amount;
    }
}

bool VendingMachine::selectItem(const std::string& code) {
    for (auto& slot : slots) {
        if (slot.code == code) {
            if (slot.item.quantity <= 0) return false;
            if (insertedMoney < slot.item.price) return false;

            insertedMoney -= slot.item.price;
            totalEarnings += slot.item.price;
            slot.item.quantity--;
            return true;
        }
    }
    return false;
}

void VendingMachine::returnMoney() {
    insertedMoney = 0.0;
}

void VendingMachine::restock() {
    for (auto& slot : slots) {
        slot.item.quantity = 10;
    }
}

double VendingMachine::collectEarnings() {
    double earned = totalEarnings;
    totalEarnings = 0.0;
    return earned;
}

double VendingMachine::getInsertedMoney() const {
    return insertedMoney;
}

// Owner authentication (stub for GUI)
bool VendingMachine::authenticateOwner() const {
    return true; // GUI will handle password dialogs
}
