#ifndef VENDINGMACHINE_H
#define VENDINGMACHINE_H

#include <string>
#include <vector>

struct Item {
    std::string name;
    double price;
    int quantity;
    Item(std::string n = "", double p = 0.0, int q = 0);
};

struct Slot {
    std::string code;
    Item item;
    Slot(std::string c = "", Item it = Item());
};

class VendingMachine {
public:
    VendingMachine();
    void initializeInventory();
    void insertMoney(double amount);
    bool selectItem(const std::string& code);
    void returnMoney();
    void restock();
    double collectEarnings();
    double getInsertedMoney() const;
    const std::vector<Slot>& getSlots() const { return slots; }

private:
    std::vector<Slot> slots;
    double insertedMoney;
    double totalEarnings;
    const std::string OWNER_PASSWORD;

    bool authenticateOwner() const;
};

#endif
