#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QTableWidgetItem>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Set up inventory table columns
    ui->inventoryTable->setColumnWidth(0, 80);   // Code
    ui->inventoryTable->setColumnWidth(1, 200);  // Item name
    ui->inventoryTable->setColumnWidth(2, 80);   // Price
    ui->inventoryTable->setColumnWidth(3, 60);   // Qty

    // Update UI with current vending machine data
    updateInventoryTable();
    updateCreditLabel();

    // Connect buttons to slots
    connect(ui->insertButton, &QPushButton::clicked, this, &MainWindow::onInsertClicked);
    connect(ui->selectButton, &QPushButton::clicked, this, &MainWindow::onSelectClicked);
    connect(ui->returnButton, &QPushButton::clicked, this, &MainWindow::onReturnClicked);
    connect(ui->restockButton, &QPushButton::clicked, this, &MainWindow::onRestockClicked);
    connect(ui->collectButton, &QPushButton::clicked, this, &MainWindow::onCollectClicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

/* ------------------------------
        UI UPDATE HELPERS
   ------------------------------ */

void MainWindow::updateInventoryTable()
{
    ui->inventoryTable->setRowCount(vm.getSlots().size());

    int row = 0;
    for (const Slot &slot : vm.getSlots()) {
        ui->inventoryTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(slot.code)));
        ui->inventoryTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(slot.item.name)));
        ui->inventoryTable->setItem(row, 2, new QTableWidgetItem(QString::number(slot.item.price, 'f', 2)));
        ui->inventoryTable->setItem(row, 3, new QTableWidgetItem(QString::number(slot.item.quantity)));
        row++;
    }
}

void MainWindow::updateCreditLabel()
{
    double credit = vm.getInsertedMoney();
    ui->creditLabel->setText("Credit: $" + QString::number(credit, 'f', 2));
}

/* ------------------------------
        BUTTON BEHAVIOUR
   ------------------------------ */

void MainWindow::onInsertClicked()
{
    QString amtText = ui->insertLineEdit->text().trimmed();

    if (amtText.isEmpty()) {
        QMessageBox::warning(this, "Error", "Please enter an amount.");
        return;
    }

    bool ok = false;
    double amount = amtText.toDouble(&ok);

    if (!ok || amount <= 0) {
        QMessageBox::warning(this, "Error", "Invalid money amount.");
        return;
    }

    vm.insertMoney(amount);
    updateCreditLabel();

    ui->insertLineEdit->clear();
}

void MainWindow::onSelectClicked()
{
    QString code = ui->selectLineEdit->text().trimmed();

    if (code.isEmpty()) {
        QMessageBox::warning(this, "Error", "Enter an item code (e.g., A1).");
        return;
    }

    if (!vm.selectItem(code.toStdString())) {
        QMessageBox::warning(this, "Error", "Purchase failed:\n- Invalid code\n- Out of stock\n- Not enough credit");
        return;
    }

    updateInventoryTable();
    updateCreditLabel();

    ui->selectLineEdit->clear();
}

void MainWindow::onReturnClicked()
{
    double refund = vm.getInsertedMoney();
    vm.returnMoney();
    updateCreditLabel();

    QMessageBox::information(this, "Money Returned",
                             "Returned $" + QString::number(refund, 'f', 2));
}

void MainWindow::onRestockClicked()
{
    vm.restock();
    updateInventoryTable();

    QMessageBox::information(this, "Restocked", "All items have been refilled to 10.");
}

void MainWindow::onCollectClicked()
{
    double earnings = vm.collectEarnings();

    QMessageBox::information(this, "Earnings Collected",
                             "Owner collected $" + QString::number(earnings, 'f', 2));
}
