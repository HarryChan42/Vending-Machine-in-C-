#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "VendingMachine.h"
#include "ui_mainwindow.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onInsertClicked();
    void onSelectClicked();
    void onReturnClicked();
    void onRestockClicked();
    void onCollectClicked();

private:
    Ui::MainWindow *ui;
    VendingMachine vm;

    void updateInventoryTable();
    void updateCreditLabel();
};

#endif // MAINWINDOW_H
